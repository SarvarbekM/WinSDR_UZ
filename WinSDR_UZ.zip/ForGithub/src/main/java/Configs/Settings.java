package Configs;

public class Settings {

    public static final String SETTINGS_FILE_ADDRESS="Settings.set";
    public static final String STATION_FILE_ADDRESS="stationFileAddress";
    public static final String TRIGGER="trigger";
    public static final String DATA_FILES_PATH="dataFilesPath";
    public static final String CUT_FILES_PATH="cutFilesPath";
    public static final String SCROLL_VALUE="scrollvalue";

    private boolean trigger;
    private String stationFileAddress;
    private String dataFilesPath;
    private String cutFilesPath;
    private int scrollvalue;

    public boolean isTrigger() {
        return trigger;
    }

    public void setTrigger(boolean trigger) {
        this.trigger = trigger;
    }

    public String getStationFileAddress() {
        return stationFileAddress;
    }

    public void setStationFileAddress(String stationFileAddress) {
        this.stationFileAddress = stationFileAddress;
    }

    public String getDataFilesPath() {
        return dataFilesPath;
    }

    public void setDataFilesPath(String dataFilesPath) {
        this.dataFilesPath = dataFilesPath;
    }

    public String getCutFilesPath() {
        return cutFilesPath;
    }

    public void setCutFilesPath(String cutFilesPath) {
        this.cutFilesPath = cutFilesPath;
    }

    public int getScrollvalue() {
        return scrollvalue;
    }

    public void setScrollvalue(int scrollvalue) {
        this.scrollvalue = scrollvalue;
    }
}
