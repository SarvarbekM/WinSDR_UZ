package Configs;

import mseed.DataRecord;

public interface IDataRecordProgress {
    void onDataRecordProgress(DataRecord record);
    void isWorking(boolean value);
}
