package Configs;

public enum TypeServer {
    IRIS,
    Local,
    Unknown,
}
