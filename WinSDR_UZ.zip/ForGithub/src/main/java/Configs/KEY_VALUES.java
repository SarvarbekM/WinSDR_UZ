package Configs;

public interface KEY_VALUES {
    String TypeServer="TypeServer";
    String IRIS="IRIS";
    String Local="Local";
    String Host="Host";
    String Port="Port";
    String Stationname="Stationname";
    String Amplituda="Amplituda";
    //String DataFilename="DataFilename";
    String Network="Network";
    String Stationcode="Stationcode";
    String STATIONS_BASE_DIRECTORY="Stations";
    String Split_CHAR="\\^";
    String Channel="Channel";
//    String TimeOutSecond="TimeOutSecond";
//    String IsSlArchive="IsSlArchive";
//    String Start="Start";
//    String End="End";
}
