package Controllers;

import Controls.BorderedTitledPane;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.Node;
import javafx.scene.Scene;
import javafx.scene.control.Label;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.SwipeEvent;
import javafx.scene.layout.*;
import javafx.scene.paint.ImagePattern;
import javafx.stage.Stage;

import java.net.URL;
import java.util.ResourceBundle;
import java.util.function.Predicate;

public class AboutController implements Initializable {
    //<editor-fold desc="Controls">
    @FXML
    private BorderedTitledPane borderPane;
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private Label label;
    @FXML
    private ImageView imageView;
    @FXML
    private ImageView icoImageView;
    //</editor-fold>

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        Image image = new Image("file:fon.jpg");
        imageView.setImage(image);
        Image ico=new Image("file:ico.png");
        icoImageView.setImage(ico);
//        anchorPane.getChildren().filtered(node -> {
//            ImageView imv=(ImageView)node;
//            return imv.equals(imageView);
//        }).get(0).setOnSwipeDown(new EventHandler<SwipeEvent>() {
//            @Override
//            public void handle(SwipeEvent event) {
//
//            }
//        });
    }
}
