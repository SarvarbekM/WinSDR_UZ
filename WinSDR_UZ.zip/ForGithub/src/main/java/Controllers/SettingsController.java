package Controllers;

import Configs.Settings;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;
import javafx.stage.DirectoryChooser;
import javafx.stage.FileChooser;
import javafx.stage.Stage;

import java.awt.*;
import java.io.File;
import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

public class SettingsController implements Initializable {
    //<editor-fold desc="Controls">
    @FXML
    private TextField stnFIleTF;
    @FXML
    private Button stnFileButton;
    @FXML
    private TextField dataFilePathTF;
    @FXML
    private Button dataFilePathButton;
    @FXML
    private TextField cutFilePathTF;
    @FXML
    private Button cutFilePathButton;
    @FXML
    private Button okButton;
    @FXML
    private Button cancelButton;
    //</editor-fold>

    private final Settings settings;

    public SettingsController(final Settings settings) {
        this.settings = settings;
    }


    private Desktop desktop = Desktop.getDesktop();

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        stnFIleTF.setText(settings.getStationFileAddress());
        dataFilePathTF.setText(settings.getDataFilesPath());
        cutFilePathTF.setText(settings.getCutFilesPath());
        stnFileButton.setOnAction(event -> {
            FileChooser fileChooser = new FileChooser();
            configureFileChooser(fileChooser);
            File file = fileChooser.showOpenDialog(cancelButton.getScene().getWindow());
            if (file != null) {
                openFile(file);
            }
        });

        cutFilePathButton.setOnAction(event -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            File selectedDirectory = directoryChooser.showDialog(cancelButton.getScene().getWindow());
            if (selectedDirectory != null) {
                cutFilePathTF.setText(selectedDirectory.getAbsolutePath());
            }
        });
        dataFilePathButton.setOnAction(event -> {
            DirectoryChooser directoryChooser = new DirectoryChooser();
            File selectedDirectory = directoryChooser.showDialog(dataFilePathButton.getScene().getWindow());
            if (selectedDirectory != null) {
                dataFilePathTF.setText(selectedDirectory.getPath());
            }
        });
        cancelButton.setOnMouseClicked(event -> ((Stage) cancelButton.getScene().getWindow()).close());
        okButton.setOnAction(event -> {
            settings.setStationFileAddress(stnFIleTF.getText());
            settings.setDataFilesPath(dataFilePathTF.getText());
            settings.setCutFilesPath(cutFilePathTF.getText());
            ((Stage) cancelButton.getScene().getWindow()).close();
        });
    }

    private static void configureFileChooser(
            final FileChooser fileChooser) {
        fileChooser.setTitle("View StationPC.Station Files");
        fileChooser.setInitialDirectory(
                new File(System.getProperty("user.home"))
        );
        fileChooser.getExtensionFilters().addAll(
                new FileChooser.ExtensionFilter("STN files", "*.stn"),
                new FileChooser.ExtensionFilter("XML files", "*.xml"),
                new FileChooser.ExtensionFilter("All Files", "*.*")
        );
    }

    private void openFile(File file) {
        System.out.println(file.getName());
        try {
            desktop.open(file);
        } catch (IOException ex) {
            ex.printStackTrace();
        }
    }
}