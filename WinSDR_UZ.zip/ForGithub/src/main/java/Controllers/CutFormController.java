package Controllers;

import Controls.DateTimePicker;
import StationPC.Station;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.geometry.Insets;
import javafx.scene.control.Button;
import javafx.scene.control.DatePicker;
import javafx.scene.layout.AnchorPane;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.ResourceBundle;

public class CutFormController implements Initializable {
    //<editor-fold desc="Controls">
    @FXML
    private AnchorPane anchorPane;
    @FXML
    private DatePicker starCutTimeDatePicker;
    @FXML
    private DatePicker endCutTimeDatePicker;
    @FXML
    private Button okButton;
    @FXML
    private Button cancelButton;
    private DateTimePicker startTimePicker;
    private DateTimePicker endTimePicker;

    //</editor-fold>

    private Station station;
    private Date startTime;
    private Date endTime;
    private String pattern;
    private String cutInputAddress;
    private String outputPath;


    public CutFormController(Station station, Date start, Date end, String cutInputAddress, String outputPath) {
        this.station = station;
        this.startTime = start;
        this.endTime = end;
        this.pattern="dd/MM/yyyy_HH:mm:ss";
        this.cutInputAddress=cutInputAddress;
        this.outputPath=outputPath;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        cancelButton.setOnMouseClicked(event -> ((Stage)cancelButton.getScene().getWindow()).close());
        okButton.setOnMouseClicked(event -> cutData());
        startTimePicker = new DateTimePicker();
        startTimePicker.setLayoutX(133);
        startTimePicker.setLayoutY(31);
        endTimePicker = new DateTimePicker();
        endTimePicker.setLayoutX(133);
        endTimePicker.setLayoutY(64);
        anchorPane.getChildren().addAll(startTimePicker,endTimePicker);
        anchorPane.setPadding(new Insets(20,20,20,20));

        if(startTime==null){
            startTime=new Date();
        }
        if(endTime==null){
            endTime=new Date();
        }
        startTimePicker.setDateTimeValue(startTime);
        endTimePicker.setDateTimeValue(endTime);
    }

    private void cutData() {
        SimpleDateFormat format=new SimpleDateFormat(pattern);

        String text="";
        text+=this.cutInputAddress+" "+outputPath+" "+format.format(startTime)+" "+format.format(endTime)+" "+pattern;
        String jarFilename="cutdatarecord.jar";

        Runtime run=Runtime.getRuntime();
        String param="java -jar "+jarFilename+" "+text;
        //String param=jarFilename+" "+text;

        System.out.println(param);
        try {
            //run.exec(param);
            run.exec("cmd.exe /c start "+param);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}