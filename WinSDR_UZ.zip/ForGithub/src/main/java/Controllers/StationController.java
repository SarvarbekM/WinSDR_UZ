package Controllers;

import Configs.IDataRecordProgress;
import Configs.Settings;
import StationPC.Station;
import edu.iris.dmc.seedcodec.CodecException;
import mseed.Btime;
import mseed.DataRecord;
import mseed.SeedFormatException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.geometry.Point2D;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.canvas.Canvas;
import javafx.scene.canvas.GraphicsContext;
import javafx.scene.control.*;
import javafx.scene.effect.BlurType;
import javafx.scene.effect.DropShadow;
import javafx.scene.effect.Light;
import javafx.scene.image.Image;
import javafx.scene.layout.*;
import javafx.scene.paint.Color;
import javafx.scene.shape.Rectangle;
import javafx.stage.Modality;
import javafx.stage.Stage;
import javafx.stage.StageStyle;
import javafx.stage.WindowEvent;

import java.io.*;
import java.net.URL;
import java.text.SimpleDateFormat;
import java.util.*;

public class StationController extends Application implements IDataRecordProgress, Initializable {
    //<editor-fold desc="Controls">
    @FXML
    private Label maxValueLabel;
    @FXML
    private Label minValueLabel;
    @FXML
    private Label nolValueLabel;
    @FXML
    private ScrollBar masshtabScroll;
    @FXML
    private Label startTimeLabel;
    @FXML
    private Label currentTimeLabel;
    @FXML
    private ToolBar statusToolBar;
    @FXML
    private Label firstPacketTimeLabel;
    @FXML
    private Label lastPacketTimeLabel;
    @FXML
    private Label packetCountLabel;
    @FXML
    private Canvas canvas;
    @FXML
    private AnchorPane canvasAnchorPane;
    @FXML
    private Label mousePositionLabel;
    @FXML
    private MenuItem appSettingsMenu;
    @FXML
    private MenuItem stationSettingsMenu;
    @FXML
    private MenuItem aboutMenu;
//</editor-fold>

    //<editor-fold desc="Global variables">
    private Station station;
    private Date starttime;
    private Date currenttime;
    private double packetlength;

    private Date mousePositionTime;
    private Date cutStartTime;
    private Date cutEndTime;
    private int pointcount;
    private double peek;
    private GraphicsContext graphicsContext;
    private int maxpointcount;
    private Point2D p1;
    private double graphicswidth;
    private double graphicsheight;
    private int maxvalue;
    private int viewminutvalue;
    private boolean isworking;
    private SimpleDateFormat dateFormat;
    private boolean isFirstdatarecord;
    private Stage stage;
    private String cutInputAddress;
    private Settings settings;
    //</editor-fold>

    //<editor-fold desc="Setters">
    private void setIsworking(boolean value) {
        if (value != this.isworking) {
            this.isworking = value;
            String styleHbox;
            if (this.isworking) {
                styleHbox = "-fx-background-color: #00FF00;";
            } else {
                styleHbox = "-fx-background-color: #FF0000;";
            }
            statusToolBar.setStyle(styleHbox);
        }
    }

    public void setStarttime(Date value) {
        this.starttime = value;
        Platform.runLater(() -> this.startTimeLabel.setText(dateFormat.format(this.starttime)));
    }

    private void setCurrenttime(Date currenttime) {
        this.currenttime = currenttime;
        Platform.runLater(() -> this.currentTimeLabel.setText(dateFormat.format(this.currenttime)));
    }

    private void setFirstpackettimeLabel(Date firstpackettime) {
        Platform.runLater(() -> this.firstPacketTimeLabel.setText("First packet time: '" + String.valueOf(firstpackettime) + "'"));
    }

    private void setLastpackettimeLabel(Date lastpackettime) {
        Platform.runLater(() -> this.lastPacketTimeLabel.setText("Last packet time: '" + String.valueOf(lastpackettime) + "'"));
    }

    private void setPacketlength(double value) {
        this.packetlength = value;
        Platform.runLater(() -> this.packetCountLabel.setText("Packet count: '" + String.valueOf(packetlength) + "'"));
    }

    public void setData(double[] data) {
        if (data != null && data.length != 0) {
            for (double aData : data) {
                if (pointcount >= maxpointcount) {
                    this.UpdateGraphics();
                }
                Point2D p2 = new Point2D(pointcount * graphicswidth / maxpointcount, aData);
                Draw(p1, p2);
                pointcount++;
                this.p1 = p2;
            }
        }
    }
//</editor-fold>

    //<editor-fold desc="Update UI Function">
    private void Draw(Point2D point1, Point2D point2) {
        Point2D p1 = ChangePonitF(point1);
        Point2D p2 = ChangePonitF(point2);
        graphicsContext.strokeLine(p1.getX(), p1.getY(), p2.getX(), p2.getY());
    }

    private Point2D ChangePonitF(Point2D point) {
        double y = (point.getY() * graphicsheight * 0.4) / maxvalue;
        return new Point2D(point.getX(), graphicsheight * 0.5 - y);
    }

    private void UpdateGraphics() {
        this.setPacketlength(0);
        isFirstdatarecord = true;
        this.graphicsContext.clearRect(0, 0, this.graphicswidth, this.graphicsheight);
        canvas.setWidth(this.canvasAnchorPane.getWidth());
        canvas.setHeight(this.canvasAnchorPane.getHeight());

        graphicswidth = graphicsContext.getCanvas().getWidth();
        graphicsheight = graphicsContext.getCanvas().getHeight();

        Point2D point1 = new Point2D(0, this.graphicsheight * 0.1);                 //Tepadan 10 % joy
        Point2D point2 = new Point2D(this.graphicswidth, this.graphicsheight * 0.1);   //qoladi
        Point2D point3 = new Point2D(0, this.graphicsheight * 0.5);                 //O'rtadagi chiziq, 50 % joy
        Point2D point4 = new Point2D(this.graphicswidth, this.graphicsheight * 0.5);   //qoladi
        Point2D point5 = new Point2D(0, (float) (this.graphicsheight * 0.9));                 //Tepadan 90 % joy
        Point2D point6 = new Point2D(this.graphicswidth, this.graphicsheight * 0.9);   //qoladi

        graphicsContext.strokeLine(point1.getX(), point1.getY(), point2.getX(), point2.getY());
        graphicsContext.strokeLine(point3.getX(), point3.getY(), point4.getX(), point4.getY());
        graphicsContext.strokeLine(point5.getX(), point5.getY(), point6.getX(), point6.getY());

        minValueLabel.setLayoutY(point5.getY() - minValueLabel.getHeight() / 2);
        nolValueLabel.setLayoutY(point3.getY() - nolValueLabel.getHeight() / 2);
        maxValueLabel.setLayoutY(point1.getY() - maxValueLabel.getHeight() / 2);

        pointcount = 0;
        peek = 0.02;
        maxpointcount = (int) ((viewminutvalue * 60) / peek);
        graphicsContext.setStroke(Color.BLACK);
        p1 = new Point2D(0, 0);
        maxvalue = (int) (masshtabScroll.getValue() * 10);
        Platform.runLater(() -> {
            maxValueLabel.setText(String.valueOf(maxvalue));
            nolValueLabel.setText("0");
            minValueLabel.setText("-" + String.valueOf(maxvalue));
        });
    }

    private Date Convert_Btime_To_Datetime(Btime btime) {
        //Calendar now = Calendar.getInstance(TimeZone.getTimeZone("UTC"));
        Calendar now = btime.convertToCalendar();
        System.out.println(now.toString());

        SimpleDateFormat dateFormat=new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
        System.out.println("date="+dateFormat.format(now.getTime()));
        //now.setTime(btime.convertToCalendar().getTime());
        //System.out.println("cal year="+now.get(Calendar.YEAR));
        return now.getTime();
        //return new Date(now.get(Calendar.YEAR), now.get(Calendar.MONTH), now.get(Calendar.), btime.hour, btime.min, btime.sec);
    }
    //</editor-fold>

    public StationController(Stage stage, Settings settings) {
        this.stage = stage;
        station = new Station(this);
        this.settings=settings;
    }

    @Override
    public void initialize(URL location, ResourceBundle resources) {
        System.out.println("settings.getScrollvalue="+settings.getScrollvalue());
        station.readStationDataFromFile(settings.getStationFileAddress());
        dateFormat = new SimpleDateFormat("HH:mm:ss");
        this.viewminutvalue = 30;

        masshtabScroll.setMin(1);
        masshtabScroll.setMax(15000);
        masshtabScroll.setValue(settings.getScrollvalue());
        masshtabScroll.valueProperty().addListener((observable, oldValue, newValue) -> {UpdateGraphics();settings.setScrollvalue(newValue.intValue());});
        canvas.setOnMouseMoved(this::mouseMovefunction);
        graphicsContext = canvas.getGraphicsContext2D();

        EventHandler<WindowEvent> confirmCloseEventHandler = event -> {
            Alert closeConfirmation = new Alert(
                    Alert.AlertType.CONFIRMATION,
                    "Are you sure you want to exit?"
            );
            Button exitButton = (Button) closeConfirmation.getDialogPane().lookupButton(
                    ButtonType.OK
            );
            exitButton.setText("Exit");
            closeConfirmation.setHeaderText("Confirm Exit");
            closeConfirmation.initModality(Modality.APPLICATION_MODAL);
            closeConfirmation.initOwner(stage);

            Optional<ButtonType> closeResponse = closeConfirmation.showAndWait();
            if (!ButtonType.OK.equals(closeResponse.get())) {
                event.consume();

            } else {
                stopStation();
            }
        };
        stage.setOnCloseRequest(confirmCloseEventHandler);
        stage.setTitle(station.getStationname());
        stage.widthProperty().addListener((observable, oldValue, newValue) -> UpdateGraphics());
        stage.heightProperty().addListener((observable, oldValue, newValue) -> UpdateGraphics());


        final Rectangle selection = new Rectangle();
        final Light.Point anchor = new Light.Point();
        canvas.setOnMousePressed(event -> {
            anchor.setX(event.getX());
            anchor.setY(event.getY());
            selection.setX(event.getX());
            selection.setY(event.getY());
            selection.setFill(Color.gray(0.5, 0.5)); // transparent
            selection.setStroke(Color.BLACK); // border
            selection.getStrokeDashArray().add(10.0);
            canvasAnchorPane.getChildren().add(selection);
            if (mousePositionTime != null) {
                cutStartTime = mousePositionTime;
                System.out.println("cutStartTime=" + cutStartTime.toString());
            }
        });

        canvas.setOnMouseDragged(event -> {
            mouseMovefunction(event);
            selection.setWidth(Math.abs(event.getX() - anchor.getX()));
            selection.setHeight(canvas.getHeight());
            selection.setX(Math.min(anchor.getX(), event.getX()));
            selection.setY(canvas.getLayoutY());
        });

        canvas.setOnMouseReleased(event -> {
            canvasAnchorPane.getChildren().remove(selection);
            selection.setWidth(0);
            selection.setHeight(0);

            if (mousePositionTime != null) {
                cutEndTime = mousePositionTime;
            }
            openCutForm();
        });

        appSettingsMenu.setOnAction(event -> openSettingsForm());
        aboutMenu.setOnAction(event -> openAboutForm());
    }

    private void openAboutForm() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../Forms/AboutForm.fxml"));
            AboutController controller = new AboutController();
            loader.setController(controller);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.getIcons().add(new Image("file:ico.png"));
            stage.setScene(new Scene(root));
//            stage.getScene().getRoot().setEffect(new DropShadow(BlurType.THREE_PASS_BOX, Color.BLACK, 25, 0.5, 0, 0));
//            stage.getScene().setFill(Color.TRANSPARENT);
            stage.setResizable(false);
            stage.setTitle("About Software");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void openSettingsForm() {
        try {
            FXMLLoader loader = new FXMLLoader(getClass().getResource("../Forms/SettingsForm.fxml"));
            SettingsController controller = new SettingsController(settings);
            loader.setController(controller);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.getScene().getRoot().setEffect(new DropShadow(BlurType.THREE_PASS_BOX, Color.BLACK, 25, 0.5, 0, 0));
            stage.getScene().setFill(Color.TRANSPARENT);
            stage.setResizable(false);
            stage.setTitle("App Settings");
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }

    }

    private void openCutForm() {
        try {
            if(cutEndTime!=null && cutStartTime!=null){
                if(cutStartTime.after(cutEndTime)){
                    Date date= (Date) cutStartTime.clone();
                    cutStartTime= (Date) cutEndTime.clone();
                    cutEndTime=date;
                }
            }

            FXMLLoader loader = new FXMLLoader(getClass().getResource("../Forms/CutForm.fxml"));
            CutFormController controller = new CutFormController(station, cutStartTime, cutEndTime, cutInputAddress, settings.getCutFilesPath());
            loader.setController(controller);
            Parent root = loader.load();
            Stage stage = new Stage();
            stage.setScene(new Scene(root));
            stage.getScene().getRoot().setEffect(new DropShadow(BlurType.THREE_PASS_BOX, Color.BLACK, 25, 0.5, 0, 0));
            stage.getScene().setFill(Color.TRANSPARENT);
            stage.initStyle(StageStyle.UNDECORATED);
            stage.initModality(Modality.APPLICATION_MODAL);
            stage.showAndWait();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    public void start() {
        stage.setTitle(station.getStationname());
        station.start();
    }

    private void saveDataFiles(DataRecord record) {
        File file = new File(settings.getDataFilesPath()+"\\Default_Station");
        if(!file.exists()){
            file.mkdirs();
        }
        SimpleDateFormat dateFormat=new SimpleDateFormat("dd_MM_yyy");
        String filename=settings.getDataFilesPath()+"\\Default_Station\\"+dateFormat.format(currenttime);
        cutInputAddress=filename;
        file=new File(filename);
        if (!file.exists()) {
            try {
                file.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        try {
            DataOutputStream dos = new DataOutputStream(new FileOutputStream(file,true));
            record.write(dos);
            dos.flush();
            dos.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void mouseMovefunction(javafx.scene.input.MouseEvent e) {
        if (this.starttime != null) {
            double x = graphicswidth / maxpointcount;
            Date time = (Date) this.starttime.clone();
            time.setSeconds((int) (time.getSeconds() + peek * e.getX() / x));
            this.mousePositionLabel.setText("UTC time: " + time.getHours() + ":" + time.getMinutes() + ":" + time.getSeconds());
            mousePositionTime = time;
        }
    }

    @Override
    public void onDataRecordProgress(DataRecord record) {
        responseDataRecord(record);
        try {
            Thread.sleep(1000);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
    }

    private void responseDataRecord(DataRecord record) {
        if (isFirstdatarecord) {
            Date date = Convert_Btime_To_Datetime(record.getHeader().getStartBtime());
            setFirstpackettimeLabel(date);
            isFirstdatarecord = false;
            setStarttime(date);
        }
        setPacketlength(packetlength + 1);
        Date lastpacketDate = Convert_Btime_To_Datetime(record.getHeader().getLastSampleBtime());
        setLastpackettimeLabel(lastpacketDate);
        setCurrenttime(lastpacketDate);
        try {
            setData(record.decompress().getAsDouble());
            saveDataFiles(record);
        } catch (SeedFormatException | CodecException e) {
            e.printStackTrace();
        }
    }

    @Override
    public void isWorking(boolean value) {
        this.setIsworking(value);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {}

    private void stopStation() {
        station.isStop(true);
    }
}