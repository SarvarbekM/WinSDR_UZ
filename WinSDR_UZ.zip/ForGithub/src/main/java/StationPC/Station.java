package StationPC;

import Configs.IDataRecordProgress;
import Configs.KEY_VALUES;
import Configs.TypeServer;
import mseed.DataRecord;
import mseed.SeedRecord;
import seedlink.SeedlinkPacket;
import seedlink.SeedlinkReader;

import java.io.*;
import java.net.InetAddress;

public class Station extends Thread {
    //<editor-fold desc="Variables">
    private String host;
    private int port;
    private String stationname;
    private double amplituda;
    private String location;
    private String network;
    private String stationcode;
    private TypeServer typeserver;

    private SeedlinkReader seedlinkreader;
    private String channel;
    private String start;
    private String end;
    private int timeoutSeconds;

    private volatile boolean isWorking;
    private volatile boolean isStop;
    private IDataRecordProgress recordProgress;
//</editor-fold>

    public Station(IDataRecordProgress interfeys) {
        this.recordProgress = interfeys;
    }

    private boolean isConnected(String host) {
        try {
            return InetAddress.getByName(host).isReachable(5000);
        } catch (IOException e) {
            e.printStackTrace();
        }
        return false;
    }

    public String getStationcode() {
        return stationcode;
    }

    public String getStationname() {
        return stationname;
    }

    @Override
    public void run() {
        super.run();
        isStop = false;
        forThread();
    }

    private void forThread() {
        DataRecord dr = null;
        SeedlinkPacket slp;
        byte[] bytes;
        this.setIsworking(false);
        while (!isStop) {
            try {
                if (!this.isWorking) {
                    if (TypeServer.IRIS == typeserver) {
                        //seedlinkreader = new SeedlinkReader(host, port, timeoutSeconds);
                        seedlinkreader = new SeedlinkReader("rtserve.iris.washington.edu", port, timeoutSeconds);
                        seedlinkreader.select(network, stationcode, location, channel);
                        seedlinkreader.startData(start, end);
                    }
                    if (TypeServer.Local == typeserver) {
                        if (isConnected(host)) {
                            seedlinkreader = new SeedlinkReader(host, port, timeoutSeconds);
                        } else {
                            System.out.println("Not connected:" + stationname);
                        }
                    }
                }
                if (seedlinkreader != null && seedlinkreader.isConnected()) {
                    if (TypeServer.IRIS == typeserver) {
                        slp = seedlinkreader.readPacket();
                        dr = slp.getMiniSeed();
                    }
                    if (TypeServer.Local == typeserver) {
                        bytes = seedlinkreader.readMiniSEED();
                        dr = (DataRecord) SeedRecord.read(bytes);
                    }
                    this.setIsworking(true);
                }

                dataRecordProgress(dr);

                try {
                    Thread.sleep(100);
                } catch (InterruptedException e) {
                    e.printStackTrace();
                }
            } catch (Exception ex) {
                System.out.println(stationcode + "    Error: " + ex.getMessage());
                //ex.printStackTrace();
                this.setIsworking(false);
            }

        }

        seedlinkreader.close();
    }

    private void dataRecordProgress(DataRecord dr) {
        recordProgress.onDataRecordProgress(dr);
    }

    private void setIsworking(boolean value) {
        isWorking = value;
        recordProgress.isWorking(value);
    }

    public void isStop(boolean value) {
        isStop = value;
    }

    public void readStationDataFromFile(String address) {
        File file=new File(address);
        BufferedReader br;
        String line;
        try {
            int port = 16064;
            String stationname = "Default Station";
            double amplituda = 100000;
            String host = "83.69.138.20";
            String network = "UZ";
            String stationcode = "uuu";
            String location = "";
            TypeServer typeserver = TypeServer.Local;
            br = new BufferedReader(new FileReader(file));
            while ((line = br.readLine()) != null) {
                String text[] = line.split(KEY_VALUES.Split_CHAR);
                if (text[0].equals(KEY_VALUES.TypeServer)) {
                    if (text[1].equals(KEY_VALUES.IRIS)) typeserver = TypeServer.IRIS;
                    if (text[1].equals(KEY_VALUES.Local)) typeserver = TypeServer.Local;
                }
                if (text[0].equals(KEY_VALUES.Host)) {
                    host = text[1];
                }
                if (text[0].equals(KEY_VALUES.Port)) {
                    port = Integer.parseInt(text[1]);
                }
                if (text[0].equals(KEY_VALUES.Stationname)) {
                    stationname = text[1];
                }
                if (text[0].equals(KEY_VALUES.Amplituda)) {
                    amplituda = Double.parseDouble(text[1]);
                }
                if (text[0].equals(KEY_VALUES.Network)) {
                    network = text[1];
                }
                if (text[0].equals(KEY_VALUES.Stationcode)) {
                    stationcode = text[1];
                }

                this.host = host;
                this.port = port;
                this.stationname = stationname;
                this.amplituda = amplituda;
                this.network = network;
                this.stationcode = stationcode;
                this.typeserver = typeserver;
                this.location = location;

                channel = "BHZ";
                start = SeedlinkReader.EMPTY;
                end = SeedlinkReader.EMPTY;
                //timeoutSeconds = SeedlinkReader.DEFAULT_TIMEOUT_SECOND;
                timeoutSeconds = 180;
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}