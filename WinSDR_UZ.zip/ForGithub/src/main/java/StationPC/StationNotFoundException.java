package StationPC;

public class StationNotFoundException extends Exception {
    public StationNotFoundException() {
    }

    public StationNotFoundException(String message) {
        super(message);
    }

    public StationNotFoundException(Throwable cause) {
        super(cause);
    }

    public StationNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
