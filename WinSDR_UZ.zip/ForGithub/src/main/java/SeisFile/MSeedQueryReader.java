package SeisFile;

import java.io.IOException;
import java.util.Date;
import java.util.List;

import mseed.DataRecord;
import mseed.SeedFormatException;

public interface MSeedQueryReader {

    public abstract List<DataRecord> read(String network,
                                          String station,
                                          String location,
                                          String channel,
                                          Date begin,
                                          Date end) throws IOException, SeisFileException,
            SeedFormatException;
    
    public void setVerbose(boolean verbose);

    public void setTimed(boolean timed);
}