package SeisFile;


public class SeisFileRuntimeException extends RuntimeException {

    public SeisFileRuntimeException() {
    }

    public SeisFileRuntimeException(String arg0) {
        super(arg0);
    }

    public SeisFileRuntimeException(Throwable arg0) {
        super(arg0);
    }

    public SeisFileRuntimeException(String arg0, Throwable arg1) {
        super(arg0, arg1);
    }
}
