package mseed;

import java.util.Comparator;


public class DataRecordBeginComparator implements Comparator<mseed.DataRecord> {

    public int compare(mseed.DataRecord o1, mseed.DataRecord o2) {
        Btime b1 = o1.getHeader().getStartBtime();
        Btime b2 = o2.getHeader().getStartBtime();
        return btimeComparator.compare(b1, b2);
    }
    
    BtimeComparator btimeComparator = new BtimeComparator();
}

