package mseed;

/** Convience class to hold begin and end Btime, along with simple methods to test if another
 * Btime in inside the range.
 * @author crotwell
 * 
 * Created on Mar 10, 2011
 */
public class BtimeRange {
    
    mseed.Btime begin;
    mseed.Btime end;
    
    public BtimeRange(mseed.Btime begin, mseed.Btime end) {
        super();
        this.begin = begin;
        this.end = end;
    }

    public mseed.Btime getBegin() {
        return begin;
    }
    
    public mseed.Btime getEnd() {
        return end;
    }
    
    public boolean overlaps(mseed.Btime btime) {
        return btime.afterOrEquals(begin) && end.afterOrEquals(btime);
    }
    
    public boolean overlaps(BtimeRange range) {
        return ! (range.getBegin().after(getEnd()) || getBegin().after(range.getEnd()));
    }
}
