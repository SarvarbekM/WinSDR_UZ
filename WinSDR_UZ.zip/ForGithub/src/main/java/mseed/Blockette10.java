package mseed;


public class Blockette10 extends ControlRecordLengthBlockette {

    public Blockette10(byte[] info) {
        super(info);
    }

    @Override
    public int getType() {
        return 10;
    }

    @Override
    public String getName() {
        return "Volume Identifier Blockette";
    }

    public String getBeginningTime() {
        return mseed.Utility.extractVarString(info, 23, 22);
    }

    public String getEndTime() {
        return mseed.Utility.extractVarString(info, 23+getBeginningTime().length()+1, 22);
    }

    public String getVolumeTime() {
        return mseed.Utility.extractVarString(info, 23+getBeginningTime().length()+1+getEndTime().length()+1, 22);
    }

    public String getOriginatingOrganization() {
        return mseed.Utility.extractVarString(info, 23+getBeginningTime().length()+1+getEndTime().length()+1+getVolumeTime().length()+1, 80);
    }

    public String getLabel() {
        return mseed.Utility.extractVarString(info, 23+getBeginningTime().length()+1+getEndTime().length()+1+getVolumeTime().length()+1+getOriginatingOrganization().length()+1, 80);
    }
    
}
