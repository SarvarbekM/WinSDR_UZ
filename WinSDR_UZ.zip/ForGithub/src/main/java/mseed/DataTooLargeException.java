package mseed;


public class DataTooLargeException extends mseed.SeedFormatException {

    public DataTooLargeException() {
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(String s) {
        super(s);
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(Throwable cause) {
        super(cause);
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(String s, Throwable cause) {
        super(s, cause);
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(String s, mseed.DataHeader header) {
        super(s, header);
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(Throwable cause, mseed.DataHeader header) {
        super(cause, header);
        // TODO Auto-generated constructor stub
    }

    public DataTooLargeException(String s, Throwable cause, mseed.DataHeader header) {
        super(s, cause, header);
        // TODO Auto-generated constructor stub
    }
}
