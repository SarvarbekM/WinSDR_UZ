package mseed;


public interface RecordLengthBlockette {
    
    public int getLogicalRecordLengthByte();
    
    public int getLogicalRecordLength();
}
