package mseed;

import java.io.IOException;


public interface BlocketteFactory {
    
    public mseed.Blockette parseBlockette(int type, byte[] bytes, boolean swapBytes)
    throws IOException, mseed.SeedFormatException;
    
}
