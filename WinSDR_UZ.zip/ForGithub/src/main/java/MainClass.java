import Configs.KEY_VALUES;
import Configs.Settings;
import Controllers.StationController;
import StationPC.StationNotFoundException;
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.image.Image;
import javafx.stage.Stage;

import java.io.*;

public class MainClass extends Application {
    private Settings setting;

    public static void main(String[] args) {
        launch(args);
    }

    @Override
    public void start(Stage primaryStage) throws IOException {
        loadSettings();
        FXMLLoader loader = new FXMLLoader(getClass().getResource("Forms/StationForm.fxml"));
        StationController controller = new StationController(primaryStage, setting);
        loader.setController(controller);
        Parent root = loader.load();
        primaryStage.setScene((new Scene(root, 1350, 200)));
        primaryStage.getIcons().add(new Image("file:ico.png"));
        primaryStage.show();
        controller.start();
    }

    @Override
    public void stop() throws Exception {
        super.stop();
        saveSettings();
    }

    private void saveSettings() {
        String filename=Settings.SETTINGS_FILE_ADDRESS;
        try {
            PrintWriter writer = new PrintWriter(filename, "UTF-8");
            writer.println(Settings.CUT_FILES_PATH+"^"+setting.getCutFilesPath());
            writer.println(Settings.DATA_FILES_PATH+"^"+setting.getDataFilesPath());
            writer.println(Settings.SCROLL_VALUE+"^"+setting.getScrollvalue());
            writer.println(Settings.TRIGGER+"^"+setting.isTrigger());
            writer.flush();
            writer.close();
        } catch (FileNotFoundException | UnsupportedEncodingException e) {
            e.printStackTrace();
        }
    }

    private void loadSettings() {
        boolean result=true;
        String filename=Settings.SETTINGS_FILE_ADDRESS;
        File file=new File(filename);
        if(!file.exists()){
            try {
                result = file.createNewFile();
                if(!result){
                    throw new IOException("Settings file not created");
                }
            } catch (IOException e) {
                e.printStackTrace();
            }
        }

        String cutfieslPath = getValueByKey(Settings.CUT_FILES_PATH,"D:\\CutFiles",filename);
        String datafilesPath = getValueByKey(Settings.DATA_FILES_PATH, "C:\\DataFiles",filename);
        int scrollValue = Integer.parseInt(getValueByKey(Settings.SCROLL_VALUE, "3000",filename));
        boolean trigger = Boolean.parseBoolean(getValueByKey(Settings.TRIGGER, "true",filename));

        setting = new Settings();
        setting.setCutFilesPath(cutfieslPath);
        setting.setDataFilesPath(datafilesPath);
        setting.setScrollvalue(scrollValue);
        setting.setTrigger(trigger);
        setting.setStationFileAddress(loadSTNFile());
    }

    private String getValueByKey(String key,String def,String filename){
        String answer=def;
        try {
            BufferedReader reader = new BufferedReader(new FileReader(new File(filename)));
            String line;
            while ((line = reader.readLine()) != null){
                String[] lines=line.split(KEY_VALUES.Split_CHAR);
                if(lines[0].equalsIgnoreCase(key)){
                    answer=lines[1];
                }
            }
            reader.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return answer;
    }

    private String loadSTNFile() {
        File dir = new File(KEY_VALUES.STATIONS_BASE_DIRECTORY);
        File[] files = dir.listFiles((dir1, name) -> name.toLowerCase().endsWith(".stn"));
        if (files != null) {
            if (files.length != 1) {
                try {
                    throw new StationNotFoundException("Station not found");
                } catch (StationNotFoundException e) {
                    e.printStackTrace();
                }
            } else {
                File file = files[0];
                return file.getAbsolutePath();
            }
        } else {
            try {
                throw new StationNotFoundException("Station not found");
            } catch (StationNotFoundException e) {
                e.printStackTrace();
            }
        }
        return "";
    }
}